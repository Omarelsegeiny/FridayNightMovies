# Friday-Night-Movies
A Movie Website for our 313 Group Project
