from django.db import models


class Seat(models.Model):
    seat = models.CharField(max_length=50)
class Movie(models.Model):
    movieName = models.CharField(max_length=50)

class Date(models.Model):
    date = models.CharField(max_length=50)

class Time(models.Model):
    time = models.CharField(max_length=50)