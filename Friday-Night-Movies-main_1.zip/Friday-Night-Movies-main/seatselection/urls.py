from django.urls import path
from seatselection import views

urlpatterns=[
    path('', views.seatselectionview, name="seatselectionview"),
    path('savemovie/', views.savemovie, name='savemovie'),
    path('savedate/', views.savedate, name='savedate'),
    path('savetime/', views.savetime, name='savetime'),
    path('saveseat/', views.saveseats, name='saveseats')
]