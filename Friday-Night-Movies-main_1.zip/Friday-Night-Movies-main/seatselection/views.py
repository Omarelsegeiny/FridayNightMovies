from .models import Seat, Movie, Date, Time
from django.shortcuts import render
from django.http import JsonResponse





def seatselectionview(request):
    seats = Seat.objects.all()
    movies = Movie.objects.all()
    dates = Date.objects.all()
    times = Time.objects.all()

    context = {
        'seats': seats,
        'movies': movies,
        'dates': dates,
        'times': times
        }
    return render(request, 'seatselection.html', context)

def savemovie(request):
  if request.method == 'POST':
    selected_movie = request.POST.get('selected_movie')
    movie = Movie(movieName=selected_movie)
    movie.save()
    return JsonResponse({'success': True})
  else:
    return JsonResponse({'success': False})

def savedate(request):
    if request.method == 'POST':
        date = request.POST.get('date')
        new_date = Date(date=date)
        new_date.save()
        return JsonResponse({'success': True})
    else:
        return JsonResponse({'success': False})

def savetime(request):
    if request.method == 'POST':
        time = request.POST.get('time')
        new_time = Time(time=time)
        new_time.save()
        return JsonResponse({'success': True})
    else:
        return JsonResponse({'success': False})
    
def saveseats(request):
    if request.method == 'POST':
        seat = request.POST.get('seat')
        new_seat = Seat(seat=seat)
        new_seat.save()
        return JsonResponse({'success': True})
    else:
        return JsonResponse({'success': False})
    

